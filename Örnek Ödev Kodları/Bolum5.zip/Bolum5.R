summary(titanic_tr)
titanic_tr$Sex = as.factor(titanic_tr$Sex)
titanic_tr$Cabin = as.factor(titanic_tr$Cabin)
titanic_tr$Embarked = as.factor(titanic_tr$Embarked)
summary(titanic_tr)


for(i in 1:nrow(titanic_tr)){
  if(is.na(titanic_tr$Age[i])){
    titanic_tr$Age[i] <- mean(titanic_tr$Age[which(titanic_tr$Sex == titanic_tr$Sex[i])], na.rm = TRUE) } }


normalize <- function(x){
  return((x-min(x))/(max(x)-min(x))) }
titanic_tr$Age <- normalize(titanic_tr$Age)


for(i in 1:nrow(titanic_te)){
  if(is.na(titanic_te$Fare[i])){
    titanic_te$Fare[i] <- mean(titanic_te$Fare[which(titanic_te$Pclass == titanic_te$Pclass[i])], na.rm = TRUE) } }

for(i in 1:nrow(titanic_te)){
  if(is.na(titanic_te$Age[i])){
    titanic_te$Age[i] <- mean(titanic_te$Age[which(titanic_te$Sex == titanic_te$Sex[i])], na.rm = TRUE) } }

titanic_te$Age <- normalize(titanic_te$Age)


komsu <- round(sqrt(nrow(titanic_tr)))+1
model <- knn(train=titanic_tr[,c("Pclass", "Age", "SibSp", "Parch", "Fare")],
             test=titanic_te[,c("Pclass",  "Age", "SibSp", "Parch", "Fare")], 
             cl=titanic_tr[,c("Survived")], k = komsu)