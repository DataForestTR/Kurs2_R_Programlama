fibonacci <- function(sayi) {
  n=round(sayi)
  v = c(rep(NA, n))
  if (n <= 0) {
    mesaj = "Lutfen pozitif bir say� giriniz"
    print(mesaj)
    
  } else if(n <= 2) {
    v[1:n] = 1
    for (i in 1:n) {
      print(v[i])  
    }
    
    
  } else {
    v[1:2] = 1
    print(v[1])
    print(v[2])  
    for (i in 3:n) {
      v[i] = v[i-1] + v[i-2] 
      print(v[i])  
    }
  }
}
fibonacci(5)
