# Soru 1:
splom(titanic_tr[,c(5:7,9)], main = "Titanic")

# Soru 2:
Your answer
hist(titanic_tr$Age,  
     main = "Age ve Fare Histogramlari",
     xlab = "Age ve Fare Degerleri", col = "blue")

hist(titanic_tr$Fare, add = T, breaks = seq(0,520,20),  
     main = "Age ve Fare Histogramlari",
     xlab = "Age ve Fare Degerleri", 
     col = rgb(200,0,0,155, maxColorValue = 255))

# Soru 3:
boxplot(titanic_tr[,c(5,9)], main = "Titanic",
        xlab = "Degiskenler",
        col = c("orange", "green"))

# Soru 4:
attach(titanic_tr)
boxplot(Age ~ Embarked, main = "Titanic",
        xlab = "Embarked", ylab = "Yas",
        col = c("pink", "darkblue", "red"))

# Soru 5:
par(mfrow = c(1,3))

hist(titanic_tr$Age,  
     main = "Age ve Fare Histogramlari",
     xlab = "Age ve Fare Degerleri", col = "blue")

hist(titanic_tr$Fare, add = T, breaks = seq(0,520,20),  
     main = "Age ve Fare Histogramlari",
     xlab = "Age ve Fare Degerleri", 
     col = rgb(200,0,0,155, maxColorValue = 255))

boxplot(titanic_tr[,c(5,9)], main = "Titanic",
        xlab = "Degiskenler",
        col = c("orange", "green"))

# attach(titanic_tr)
boxplot(Age ~ Embarked, main = "Titanic",
        xlab = "Embarked", ylab = "Yas",
        col = c("pink", "darkblue", "red"))
