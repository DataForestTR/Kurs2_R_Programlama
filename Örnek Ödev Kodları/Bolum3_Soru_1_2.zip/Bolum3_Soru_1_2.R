nrow(titanic_tr)
ncol(titanic_tr)
head(titanic_tr)
str(titanic_tr)
summary(titanic_tr)

titanic_tr$Cabin = as.factor(titanic_tr$Cabin)
titanic_tr$Embarked = as.factor(titanic_tr$Embarked)
titanic_tr$Sex = as.factor(titanic_tr$Sex)
sapply(titanic_tr, function(x)all(print(sum(is.na(x))))) 
S = split(titanic_tr, as.factor(titanic_tr$Sex))
S$female[is.na(S$female$Age),5] <- mean(na.omit(S$female$Age))
S$male[is.na(S$male$Age),5] <- mean(na.omit(S$male$Age))
titanic_tr = rbind(S$female, S$male)
titanic_tr[is.na(titanic_tr$Fare), c("PassengerId","Pclass")]
PassengerId     Pclass
153        1044                3
titanic_tr$Fare[is.na(titanic_tr$Fare)] <- mean(na.omit(titanic_tr$Fare[titanic_tr$Pclass==3]))